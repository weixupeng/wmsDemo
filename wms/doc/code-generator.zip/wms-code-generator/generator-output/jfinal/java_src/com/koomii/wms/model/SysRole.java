/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * SysRole
 * @author 
 *
 */
public class SysRole extends Model<SysRole>{
	public static SysRole dao = new SysRole();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "sys_role";
	
	/**
	 * 记录编号
	 */
	public static final String id = "id";
	/**
	 * 创建日期
	 */
	public static final String createDate = "createDate";
	/**
	 * 修改日期
	 */
	public static final String modifyDate = "modifyDate";
	/**
	 * 名称
	 */
	public static final String name = "name";
	/**
	 * 描述
	 */
	public static final String description = "description";
	
	public SysRole(){
	}
	/**
	 * Get 记录编号
	 */
	public java.lang.String getId() {
		return get(id);
	}
	
	/**
	 * Set 记录编号
	 */
	public SysRole setId(java.lang.String value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 创建日期
	 */
	public java.util.Date getCreateDate() {
		return get(createDate);
	}
	
	/**
	 * Set 创建日期
	 */
	public SysRole setCreateDate(java.util.Date value) {
		set(createDate, value);
		return this;
	}
	/**
	 * Get 修改日期
	 */
	public java.util.Date getModifyDate() {
		return get(modifyDate);
	}
	
	/**
	 * Set 修改日期
	 */
	public SysRole setModifyDate(java.util.Date value) {
		set(modifyDate, value);
		return this;
	}
	/**
	 * Get 名称
	 */
	public java.lang.String getName() {
		return get(name);
	}
	
	/**
	 * Set 名称
	 */
	public SysRole setName(java.lang.String value) {
		set(name, value);
		return this;
	}
	/**
	 * Get 描述
	 */
	public java.lang.String getDescription() {
		return get(description);
	}
	
	/**
	 * Set 描述
	 */
	public SysRole setDescription(java.lang.String value) {
		set(description, value);
		return this;
	}
}

