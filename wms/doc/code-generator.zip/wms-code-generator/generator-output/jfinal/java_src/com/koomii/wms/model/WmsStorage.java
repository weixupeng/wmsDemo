/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * WmsStorage
 * @author 
 *
 */
public class WmsStorage extends Model<WmsStorage>{
	public static WmsStorage dao = new WmsStorage();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "wms_storage";
	
	/**
	 * 仓库号
	 */
	public static final String id = "id";
	/**
	 * 仓库名称
	 */
	public static final String name = "name";
	
	public WmsStorage(){
	}
	/**
	 * Get 仓库号
	 */
	public java.lang.String getId() {
		return get(id);
	}
	
	/**
	 * Set 仓库号
	 */
	public WmsStorage setId(java.lang.String value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 仓库名称
	 */
	public java.lang.String getName() {
		return get(name);
	}
	
	/**
	 * Set 仓库名称
	 */
	public WmsStorage setName(java.lang.String value) {
		set(name, value);
		return this;
	}
}

