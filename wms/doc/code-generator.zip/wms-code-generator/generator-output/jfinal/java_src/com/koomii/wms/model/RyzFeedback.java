/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * RyzFeedback
 * @author 
 *
 */
public class RyzFeedback extends Model<RyzFeedback>{
	public static RyzFeedback dao = new RyzFeedback();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "ryz_feedback";
	
	/**
	 * 反馈信息ID
	 */
	public static final String id = "id";
	/**
	 * 反馈时间
	 */
	public static final String createDate = "createDate";
	/**
	 * 最后修改时间
	 */
	public static final String modifyDate = "modifyDate";
	/**
	 * 反馈内容
	 */
	public static final String content = "content";
	/**
	 * 反馈人
	 */
	public static final String feedbackUserId = "feedbackUserId";
	/**
	 * 反馈类型
	 */
	public static final String type = "type";
	
	public RyzFeedback(){
	}
	/**
	 * Get 反馈信息ID
	 */
	public java.lang.String getId() {
		return get(id);
	}
	
	/**
	 * Set 反馈信息ID
	 */
	public RyzFeedback setId(java.lang.String value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 反馈时间
	 */
	public java.util.Date getCreateDate() {
		return get(createDate);
	}
	
	/**
	 * Set 反馈时间
	 */
	public RyzFeedback setCreateDate(java.util.Date value) {
		set(createDate, value);
		return this;
	}
	/**
	 * Get 最后修改时间
	 */
	public java.util.Date getModifyDate() {
		return get(modifyDate);
	}
	
	/**
	 * Set 最后修改时间
	 */
	public RyzFeedback setModifyDate(java.util.Date value) {
		set(modifyDate, value);
		return this;
	}
	/**
	 * Get 反馈内容
	 */
	public java.lang.String getContent() {
		return get(content);
	}
	
	/**
	 * Set 反馈内容
	 */
	public RyzFeedback setContent(java.lang.String value) {
		set(content, value);
		return this;
	}
	/**
	 * Get 反馈人
	 */
	public java.lang.String getFeedbackUserId() {
		return get(feedbackUserId);
	}
	
	/**
	 * Set 反馈人
	 */
	public RyzFeedback setFeedbackUserId(java.lang.String value) {
		set(feedbackUserId, value);
		return this;
	}
	/**
	 * Get 反馈类型
	 */
	public java.lang.Integer getType() {
		return get(type);
	}
	
	/**
	 * Set 反馈类型
	 */
	public RyzFeedback setType(java.lang.Integer value) {
		set(type, value);
		return this;
	}
}

