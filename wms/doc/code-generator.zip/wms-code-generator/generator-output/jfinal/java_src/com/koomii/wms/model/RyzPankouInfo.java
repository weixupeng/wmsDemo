/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * RyzPankouInfo
 * @author 
 *
 */
public class RyzPankouInfo extends Model<RyzPankouInfo>{
	public static RyzPankouInfo dao = new RyzPankouInfo();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "ryz_pankou_info";
	
	/**
	 * 盘口信息ID
	 */
	public static final String id = "id";
	/**
	 * 发盘时间
	 */
	public static final String createDate = "createDate";
	/**
	 * 最后修改时间
	 */
	public static final String modifyDate = "modifyDate";
	/**
	 * 盘口内容
	 */
	public static final String content = "content";
	/**
	 * 结束时间
	 */
	public static final String endDate = "endDate";
	/**
	 * 盘口如意币金额
	 */
	public static final String ruyibi = "ruyibi";
	/**
	 * 盘口类别
	 */
	public static final String type = "type";
	/**
	 * 发盘者用户ID
	 */
	public static final String pubUserId = "pubUserId";
	/**
	 * 接盘者用户ID
	 */
	public static final String recUserId = "recUserId";
	/**
	 * PK发生时间
	 */
	public static final String pkDate = "pkDate";
	/**
	 * 盘口判定方式
	 */
	public static final String judgeMethod = "judgeMethod";
	/**
	 * PK结果
	 */
	public static final String outcome = "outcome";
	/**
	 * 结果判定时间
	 */
	public static final String judgeDate = "judgeDate";
	/**
	 * 盘口状态
	 */
	public static final String state = "state";
	/**
	 * 盘口访问数
	 */
	public static final String pv = "pv";
	
	public RyzPankouInfo(){
	}
	/**
	 * Get 盘口信息ID
	 */
	public java.lang.String getId() {
		return get(id);
	}
	
	/**
	 * Set 盘口信息ID
	 */
	public RyzPankouInfo setId(java.lang.String value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 发盘时间
	 */
	public java.util.Date getCreateDate() {
		return get(createDate);
	}
	
	/**
	 * Set 发盘时间
	 */
	public RyzPankouInfo setCreateDate(java.util.Date value) {
		set(createDate, value);
		return this;
	}
	/**
	 * Get 最后修改时间
	 */
	public java.util.Date getModifyDate() {
		return get(modifyDate);
	}
	
	/**
	 * Set 最后修改时间
	 */
	public RyzPankouInfo setModifyDate(java.util.Date value) {
		set(modifyDate, value);
		return this;
	}
	/**
	 * Get 盘口内容
	 */
	public java.lang.String getContent() {
		return get(content);
	}
	
	/**
	 * Set 盘口内容
	 */
	public RyzPankouInfo setContent(java.lang.String value) {
		set(content, value);
		return this;
	}
	/**
	 * Get 结束时间
	 */
	public java.util.Date getEndDate() {
		return get(endDate);
	}
	
	/**
	 * Set 结束时间
	 */
	public RyzPankouInfo setEndDate(java.util.Date value) {
		set(endDate, value);
		return this;
	}
	/**
	 * Get 盘口如意币金额
	 */
	public java.lang.Integer getRuyibi() {
		return get(ruyibi);
	}
	
	/**
	 * Set 盘口如意币金额
	 */
	public RyzPankouInfo setRuyibi(java.lang.Integer value) {
		set(ruyibi, value);
		return this;
	}
	/**
	 * Get 盘口类别
	 */
	public java.lang.Integer getType() {
		return get(type);
	}
	
	/**
	 * Set 盘口类别
	 */
	public RyzPankouInfo setType(java.lang.Integer value) {
		set(type, value);
		return this;
	}
	/**
	 * Get 发盘者用户ID
	 */
	public java.lang.String getPubUserId() {
		return get(pubUserId);
	}
	
	/**
	 * Set 发盘者用户ID
	 */
	public RyzPankouInfo setPubUserId(java.lang.String value) {
		set(pubUserId, value);
		return this;
	}
	/**
	 * Get 接盘者用户ID
	 */
	public java.lang.String getRecUserId() {
		return get(recUserId);
	}
	
	/**
	 * Set 接盘者用户ID
	 */
	public RyzPankouInfo setRecUserId(java.lang.String value) {
		set(recUserId, value);
		return this;
	}
	/**
	 * Get PK发生时间
	 */
	public java.util.Date getPkDate() {
		return get(pkDate);
	}
	
	/**
	 * Set PK发生时间
	 */
	public RyzPankouInfo setPkDate(java.util.Date value) {
		set(pkDate, value);
		return this;
	}
	/**
	 * Get 盘口判定方式
	 */
	public java.lang.Integer getJudgeMethod() {
		return get(judgeMethod);
	}
	
	/**
	 * Set 盘口判定方式
	 */
	public RyzPankouInfo setJudgeMethod(java.lang.Integer value) {
		set(judgeMethod, value);
		return this;
	}
	/**
	 * Get PK结果
	 */
	public java.lang.Integer getOutcome() {
		return get(outcome);
	}
	
	/**
	 * Set PK结果
	 */
	public RyzPankouInfo setOutcome(java.lang.Integer value) {
		set(outcome, value);
		return this;
	}
	/**
	 * Get 结果判定时间
	 */
	public java.util.Date getJudgeDate() {
		return get(judgeDate);
	}
	
	/**
	 * Set 结果判定时间
	 */
	public RyzPankouInfo setJudgeDate(java.util.Date value) {
		set(judgeDate, value);
		return this;
	}
	/**
	 * Get 盘口状态
	 */
	public java.lang.Integer getState() {
		return get(state);
	}
	
	/**
	 * Set 盘口状态
	 */
	public RyzPankouInfo setState(java.lang.Integer value) {
		set(state, value);
		return this;
	}
	/**
	 * Get 盘口访问数
	 */
	public java.lang.Long getPv() {
		return get(pv);
	}
	
	/**
	 * Set 盘口访问数
	 */
	public RyzPankouInfo setPv(java.lang.Long value) {
		set(pv, value);
		return this;
	}
}

