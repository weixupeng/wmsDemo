/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * WmsFlow
 * @author 
 *
 */
public class WmsFlow extends Model<WmsFlow>{
	public static WmsFlow dao = new WmsFlow();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "wms_flow";
	
	/**
	 * 流水ID
	 */
	public static final String id = "id";
	/**
	 * 类型
	 */
	public static final String type = "type";
	/**
	 * 单据号
	 */
	public static final String formId = "formId";
	/**
	 * 入库仓库号
	 */
	public static final String inStorage = "inStorage";
	/**
	 * 盘点仓库
	 */
	public static final String stStorage = "stStorage";
	/**
	 * 出库仓库号
	 */
	public static final String outStorage = "outStorage";
	/**
	 * 货号
	 */
	public static final String materialId = "materialId";
	/**
	 * 货物名称
	 */
	public static final String materialName = "materialName";
	/**
	 * 变动数量
	 */
	public static final String quantity = "quantity";
	/**
	 * 变动时间
	 */
	public static final String createDate = "createDate";
	/**
	 * 作业人
	 */
	public static final String worker = "worker";
	/**
	 * 操作人
	 */
	public static final String operator = "operator";
	
	public WmsFlow(){
	}
	/**
	 * Get 流水ID
	 */
	public java.lang.Long getId() {
		return get(id);
	}
	
	/**
	 * Set 流水ID
	 */
	public WmsFlow setId(java.lang.Long value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 类型
	 */
	public java.lang.Integer getType() {
		return get(type);
	}
	
	/**
	 * Set 类型
	 */
	public WmsFlow setType(java.lang.Integer value) {
		set(type, value);
		return this;
	}
	/**
	 * Get 单据号
	 */
	public java.lang.Long getFormId() {
		return get(formId);
	}
	
	/**
	 * Set 单据号
	 */
	public WmsFlow setFormId(java.lang.Long value) {
		set(formId, value);
		return this;
	}
	/**
	 * Get 入库仓库号
	 */
	public java.lang.String getInStorage() {
		return get(inStorage);
	}
	
	/**
	 * Set 入库仓库号
	 */
	public WmsFlow setInStorage(java.lang.String value) {
		set(inStorage, value);
		return this;
	}
	/**
	 * Get 盘点仓库
	 */
	public java.lang.String getStStorage() {
		return get(stStorage);
	}
	
	/**
	 * Set 盘点仓库
	 */
	public WmsFlow setStStorage(java.lang.String value) {
		set(stStorage, value);
		return this;
	}
	/**
	 * Get 出库仓库号
	 */
	public java.lang.String getOutStorage() {
		return get(outStorage);
	}
	
	/**
	 * Set 出库仓库号
	 */
	public WmsFlow setOutStorage(java.lang.String value) {
		set(outStorage, value);
		return this;
	}
	/**
	 * Get 货号
	 */
	public java.lang.Long getMaterialId() {
		return get(materialId);
	}
	
	/**
	 * Set 货号
	 */
	public WmsFlow setMaterialId(java.lang.Long value) {
		set(materialId, value);
		return this;
	}
	/**
	 * Get 货物名称
	 */
	public java.lang.String getMaterialName() {
		return get(materialName);
	}
	
	/**
	 * Set 货物名称
	 */
	public WmsFlow setMaterialName(java.lang.String value) {
		set(materialName, value);
		return this;
	}
	/**
	 * Get 变动数量
	 */
	public java.lang.Double getQuantity() {
		return get(quantity);
	}
	
	/**
	 * Set 变动数量
	 */
	public WmsFlow setQuantity(java.lang.Double value) {
		set(quantity, value);
		return this;
	}
	/**
	 * Get 变动时间
	 */
	public java.util.Date getCreateDate() {
		return get(createDate);
	}
	
	/**
	 * Set 变动时间
	 */
	public WmsFlow setCreateDate(java.util.Date value) {
		set(createDate, value);
		return this;
	}
	/**
	 * Get 作业人
	 */
	public java.lang.Long getWorker() {
		return get(worker);
	}
	
	/**
	 * Set 作业人
	 */
	public WmsFlow setWorker(java.lang.Long value) {
		set(worker, value);
		return this;
	}
	/**
	 * Get 操作人
	 */
	public java.lang.String getOperator() {
		return get(operator);
	}
	
	/**
	 * Set 操作人
	 */
	public WmsFlow setOperator(java.lang.String value) {
		set(operator, value);
		return this;
	}
}

