/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * WmsCustomer
 * @author 
 *
 */
public class WmsCustomer extends Model<WmsCustomer>{
	public static WmsCustomer dao = new WmsCustomer();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "wms_customer";
	
	/**
	 * 编码
	 */
	public static final String id = "id";
	/**
	 * 名称
	 */
	public static final String name = "name";
	/**
	 * 类型（0供应商1客户）
	 */
	public static final String type = "type";
	
	public WmsCustomer(){
	}
	/**
	 * Get 编码
	 */
	public java.lang.Long getId() {
		return get(id);
	}
	
	/**
	 * Set 编码
	 */
	public WmsCustomer setId(java.lang.Long value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 名称
	 */
	public java.lang.String getName() {
		return get(name);
	}
	
	/**
	 * Set 名称
	 */
	public WmsCustomer setName(java.lang.String value) {
		set(name, value);
		return this;
	}
	/**
	 * Get 类型（0供应商1客户）
	 */
	public java.lang.Integer getType() {
		return get(type);
	}
	
	/**
	 * Set 类型（0供应商1客户）
	 */
	public WmsCustomer setType(java.lang.Integer value) {
		set(type, value);
		return this;
	}
}

