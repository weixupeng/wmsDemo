/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * RyzAccount
 * @author 
 *
 */
public class RyzAccount extends Model<RyzAccount>{
	public static RyzAccount dao = new RyzAccount();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "ryz_account";
	
	/**
	 * 用户Id
	 */
	public static final String id = "id";
	/**
	 * 注册时间
	 */
	public static final String createDate = "createDate";
	/**
	 * 最后修改时间
	 */
	public static final String modifyDate = "modifyDate";
	/**
	 * 注册名_登陆名
	 */
	public static final String loginName = "loginName";
	/**
	 * 登录密码
	 */
	public static final String loginPwd = "loginPwd";
	/**
	 * 昵称_显示名
	 */
	public static final String nickName = "nickName";
	/**
	 * 图片相对路径
	 */
	public static final String picPath = "picPath";
	/**
	 * 个性签名
	 */
	public static final String sign = "sign";
	/**
	 * 用户生日
	 */
	public static final String birthday = "birthday";
	/**
	 * 用户性别
	 */
	public static final String sex = "sex";
	/**
	 * 用户状态
	 */
	public static final String state = "state";
	/**
	 * 手机号
	 */
	public static final String mobile = "mobile";
	/**
	 * 用户QQ
	 */
	public static final String qq = "qq";
	/**
	 * 用户邮箱
	 */
	public static final String email = "email";
	/**
	 * 如意币总额
	 */
	public static final String ruyibiAll = "ruyibiAll";
	/**
	 * 用户开盘总数
	 */
	public static final String pkNum = "pkNum";
	/**
	 * 如意币冻结金额
	 */
	public static final String ruyibiLocked = "ruyibiLocked";
	/**
	 * 如意币可用金额
	 */
	public static final String ruyibi = "ruyibi";
	/**
	 * 登录密钥
	 */
	public static final String loginKey = "loginKey";
	/**
	 * 登录时间
	 */
	public static final String loginDate = "loginDate";
	
	public RyzAccount(){
	}
	/**
	 * Get 用户Id
	 */
	public java.lang.String getId() {
		return get(id);
	}
	
	/**
	 * Set 用户Id
	 */
	public RyzAccount setId(java.lang.String value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 注册时间
	 */
	public java.util.Date getCreateDate() {
		return get(createDate);
	}
	
	/**
	 * Set 注册时间
	 */
	public RyzAccount setCreateDate(java.util.Date value) {
		set(createDate, value);
		return this;
	}
	/**
	 * Get 最后修改时间
	 */
	public java.util.Date getModifyDate() {
		return get(modifyDate);
	}
	
	/**
	 * Set 最后修改时间
	 */
	public RyzAccount setModifyDate(java.util.Date value) {
		set(modifyDate, value);
		return this;
	}
	/**
	 * Get 注册名_登陆名
	 */
	public java.lang.String getLoginName() {
		return get(loginName);
	}
	
	/**
	 * Set 注册名_登陆名
	 */
	public RyzAccount setLoginName(java.lang.String value) {
		set(loginName, value);
		return this;
	}
	/**
	 * Get 登录密码
	 */
	public java.lang.String getLoginPwd() {
		return get(loginPwd);
	}
	
	/**
	 * Set 登录密码
	 */
	public RyzAccount setLoginPwd(java.lang.String value) {
		set(loginPwd, value);
		return this;
	}
	/**
	 * Get 昵称_显示名
	 */
	public java.lang.String getNickName() {
		return get(nickName);
	}
	
	/**
	 * Set 昵称_显示名
	 */
	public RyzAccount setNickName(java.lang.String value) {
		set(nickName, value);
		return this;
	}
	/**
	 * Get 图片相对路径
	 */
	public java.lang.String getPicPath() {
		return get(picPath);
	}
	
	/**
	 * Set 图片相对路径
	 */
	public RyzAccount setPicPath(java.lang.String value) {
		set(picPath, value);
		return this;
	}
	/**
	 * Get 个性签名
	 */
	public java.lang.String getSign() {
		return get(sign);
	}
	
	/**
	 * Set 个性签名
	 */
	public RyzAccount setSign(java.lang.String value) {
		set(sign, value);
		return this;
	}
	/**
	 * Get 用户生日
	 */
	public java.util.Date getBirthday() {
		return get(birthday);
	}
	
	/**
	 * Set 用户生日
	 */
	public RyzAccount setBirthday(java.util.Date value) {
		set(birthday, value);
		return this;
	}
	/**
	 * Get 用户性别
	 */
	public java.lang.Integer getSex() {
		return get(sex);
	}
	
	/**
	 * Set 用户性别
	 */
	public RyzAccount setSex(java.lang.Integer value) {
		set(sex, value);
		return this;
	}
	/**
	 * Get 用户状态
	 */
	public java.lang.Integer getState() {
		return get(state);
	}
	
	/**
	 * Set 用户状态
	 */
	public RyzAccount setState(java.lang.Integer value) {
		set(state, value);
		return this;
	}
	/**
	 * Get 手机号
	 */
	public java.lang.String getMobile() {
		return get(mobile);
	}
	
	/**
	 * Set 手机号
	 */
	public RyzAccount setMobile(java.lang.String value) {
		set(mobile, value);
		return this;
	}
	/**
	 * Get 用户QQ
	 */
	public java.lang.String getQq() {
		return get(qq);
	}
	
	/**
	 * Set 用户QQ
	 */
	public RyzAccount setQq(java.lang.String value) {
		set(qq, value);
		return this;
	}
	/**
	 * Get 用户邮箱
	 */
	public java.lang.String getEmail() {
		return get(email);
	}
	
	/**
	 * Set 用户邮箱
	 */
	public RyzAccount setEmail(java.lang.String value) {
		set(email, value);
		return this;
	}
	/**
	 * Get 如意币总额
	 */
	public java.lang.Long getRuyibiAll() {
		return get(ruyibiAll);
	}
	
	/**
	 * Set 如意币总额
	 */
	public RyzAccount setRuyibiAll(java.lang.Long value) {
		set(ruyibiAll, value);
		return this;
	}
	/**
	 * Get 用户开盘总数
	 */
	public java.lang.Long getPkNum() {
		return get(pkNum);
	}
	
	/**
	 * Set 用户开盘总数
	 */
	public RyzAccount setPkNum(java.lang.Long value) {
		set(pkNum, value);
		return this;
	}
	/**
	 * Get 如意币冻结金额
	 */
	public java.lang.Long getRuyibiLocked() {
		return get(ruyibiLocked);
	}
	
	/**
	 * Set 如意币冻结金额
	 */
	public RyzAccount setRuyibiLocked(java.lang.Long value) {
		set(ruyibiLocked, value);
		return this;
	}
	/**
	 * Get 如意币可用金额
	 */
	public java.lang.Long getRuyibi() {
		return get(ruyibi);
	}
	
	/**
	 * Set 如意币可用金额
	 */
	public RyzAccount setRuyibi(java.lang.Long value) {
		set(ruyibi, value);
		return this;
	}
	/**
	 * Get 登录密钥
	 */
	public java.lang.String getLoginKey() {
		return get(loginKey);
	}
	
	/**
	 * Set 登录密钥
	 */
	public RyzAccount setLoginKey(java.lang.String value) {
		set(loginKey, value);
		return this;
	}
	/**
	 * Get 登录时间
	 */
	public java.util.Date getLoginDate() {
		return get(loginDate);
	}
	
	/**
	 * Set 登录时间
	 */
	public RyzAccount setLoginDate(java.util.Date value) {
		set(loginDate, value);
		return this;
	}
}

