/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.common;

import com.jfinal.config.Routes;
import com.jfinal.core.JFinal;
import com.koomii.wms.controller.*;

/**
 * Routers
 */
public class RouteConfig{
	
	public static void config(Routes me){
		me.add("/ryzAccount", RyzAccount.class);
	}
	
	/**
	 * start JFinal Jetty with main 
	 */
	public static void main(String[] args) {
		JFinal.start("WebRoot", 80, "/", 5);
	}

}