/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * WmsMaterial
 * @author 
 *
 */
public class WmsMaterial extends Model<WmsMaterial>{
	public static WmsMaterial dao = new WmsMaterial();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "wms_material";
	
	/**
	 * 货号
	 */
	public static final String id = "id";
	/**
	 * 货物名称
	 */
	public static final String name = "name";
	/**
	 * 价格
	 */
	public static final String price = "price";
	/**
	 * 查询标志
	 */
	public static final String tag = "tag";
	
	public WmsMaterial(){
	}
	/**
	 * Get 货号
	 */
	public java.lang.Long getId() {
		return get(id);
	}
	
	/**
	 * Set 货号
	 */
	public WmsMaterial setId(java.lang.Long value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 货物名称
	 */
	public java.lang.String getName() {
		return get(name);
	}
	
	/**
	 * Set 货物名称
	 */
	public WmsMaterial setName(java.lang.String value) {
		set(name, value);
		return this;
	}
	/**
	 * Get 价格
	 */
	public java.lang.Double getPrice() {
		return get(price);
	}
	
	/**
	 * Set 价格
	 */
	public WmsMaterial setPrice(java.lang.Double value) {
		set(price, value);
		return this;
	}
	/**
	 * Get 查询标志
	 */
	public java.lang.String getTag() {
		return get(tag);
	}
	
	/**
	 * Set 查询标志
	 */
	public WmsMaterial setTag(java.lang.String value) {
		set(tag, value);
		return this;
	}
}

