/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * RyzRuyibiFlow
 * @author 
 *
 */
public class RyzRuyibiFlow extends Model<RyzRuyibiFlow>{
	public static RyzRuyibiFlow dao = new RyzRuyibiFlow();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "ryz_ruyibi_flow";
	
	/**
	 * 流水ID
	 */
	public static final String id = "id";
	/**
	 * 交易时间
	 */
	public static final String createDate = "createDate";
	/**
	 * 最后修改时间
	 */
	public static final String modifyDate = "modifyDate";
	/**
	 * 交易用户ID
	 */
	public static final String userId = "userId";
	/**
	 * 收入方式
	 */
	public static final String earningType = "earningType";
	/**
	 * 支出方式
	 */
	public static final String expenseType = "expenseType";
	/**
	 * 收入金额
	 */
	public static final String earning = "earning";
	/**
	 * 支出金额
	 */
	public static final String expense = "expense";
	/**
	 * 相关盘口ID
	 */
	public static final String pkInfoId = "pkInfoId";
	
	public RyzRuyibiFlow(){
	}
	/**
	 * Get 流水ID
	 */
	public java.lang.String getId() {
		return get(id);
	}
	
	/**
	 * Set 流水ID
	 */
	public RyzRuyibiFlow setId(java.lang.String value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 交易时间
	 */
	public java.util.Date getCreateDate() {
		return get(createDate);
	}
	
	/**
	 * Set 交易时间
	 */
	public RyzRuyibiFlow setCreateDate(java.util.Date value) {
		set(createDate, value);
		return this;
	}
	/**
	 * Get 最后修改时间
	 */
	public java.util.Date getModifyDate() {
		return get(modifyDate);
	}
	
	/**
	 * Set 最后修改时间
	 */
	public RyzRuyibiFlow setModifyDate(java.util.Date value) {
		set(modifyDate, value);
		return this;
	}
	/**
	 * Get 交易用户ID
	 */
	public java.lang.String getUserId() {
		return get(userId);
	}
	
	/**
	 * Set 交易用户ID
	 */
	public RyzRuyibiFlow setUserId(java.lang.String value) {
		set(userId, value);
		return this;
	}
	/**
	 * Get 收入方式
	 */
	public java.lang.Integer getEarningType() {
		return get(earningType);
	}
	
	/**
	 * Set 收入方式
	 */
	public RyzRuyibiFlow setEarningType(java.lang.Integer value) {
		set(earningType, value);
		return this;
	}
	/**
	 * Get 支出方式
	 */
	public java.lang.Integer getExpenseType() {
		return get(expenseType);
	}
	
	/**
	 * Set 支出方式
	 */
	public RyzRuyibiFlow setExpenseType(java.lang.Integer value) {
		set(expenseType, value);
		return this;
	}
	/**
	 * Get 收入金额
	 */
	public java.lang.Integer getEarning() {
		return get(earning);
	}
	
	/**
	 * Set 收入金额
	 */
	public RyzRuyibiFlow setEarning(java.lang.Integer value) {
		set(earning, value);
		return this;
	}
	/**
	 * Get 支出金额
	 */
	public java.lang.Integer getExpense() {
		return get(expense);
	}
	
	/**
	 * Set 支出金额
	 */
	public RyzRuyibiFlow setExpense(java.lang.Integer value) {
		set(expense, value);
		return this;
	}
	/**
	 * Get 相关盘口ID
	 */
	public java.lang.String getPkInfoId() {
		return get(pkInfoId);
	}
	
	/**
	 * Set 相关盘口ID
	 */
	public RyzRuyibiFlow setPkInfoId(java.lang.String value) {
		set(pkInfoId, value);
		return this;
	}
}

