/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * SysRoleuser
 * @author 
 *
 */
public class SysRoleuser extends Model<SysRoleuser>{
	public static SysRoleuser dao = new SysRoleuser();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "sys_roleuser";
	
	/**
	 * 记录编号
	 */
	public static final String id = "id";
	/**
	 * 创建日期
	 */
	public static final String createDate = "createDate";
	/**
	 * 修改日期
	 */
	public static final String modifyDate = "modifyDate";
	/**
	 * 角色ID
	 */
	public static final String roleId = "roleId";
	/**
	 * 用户userName
	 */
	public static final String username = "username";
	
	public SysRoleuser(){
	}
	/**
	 * Get 记录编号
	 */
	public java.lang.String getId() {
		return get(id);
	}
	
	/**
	 * Set 记录编号
	 */
	public SysRoleuser setId(java.lang.String value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 创建日期
	 */
	public java.util.Date getCreateDate() {
		return get(createDate);
	}
	
	/**
	 * Set 创建日期
	 */
	public SysRoleuser setCreateDate(java.util.Date value) {
		set(createDate, value);
		return this;
	}
	/**
	 * Get 修改日期
	 */
	public java.util.Date getModifyDate() {
		return get(modifyDate);
	}
	
	/**
	 * Set 修改日期
	 */
	public SysRoleuser setModifyDate(java.util.Date value) {
		set(modifyDate, value);
		return this;
	}
	/**
	 * Get 角色ID
	 */
	public java.lang.String getRoleId() {
		return get(roleId);
	}
	
	/**
	 * Set 角色ID
	 */
	public SysRoleuser setRoleId(java.lang.String value) {
		set(roleId, value);
		return this;
	}
	/**
	 * Get 用户userName
	 */
	public java.lang.String getUsername() {
		return get(username);
	}
	
	/**
	 * Set 用户userName
	 */
	public SysRoleuser setUsername(java.lang.String value) {
		set(username, value);
		return this;
	}
}

