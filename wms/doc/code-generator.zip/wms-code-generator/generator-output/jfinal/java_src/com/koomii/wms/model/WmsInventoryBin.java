/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * WmsInventoryBin
 * @author 
 *
 */
public class WmsInventoryBin extends Model<WmsInventoryBin>{
	public static WmsInventoryBin dao = new WmsInventoryBin();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "wms_inventory_bin";
	
	/**
	 * id
	 */
	public static final String id = "id";
	/**
	 * 仓库号
	 */
	public static final String storageId = "storageId";
	/**
	 * 仓位Id
	 */
	public static final String storageBinId = "storageBinId";
	/**
	 * 仓位编号
	 */
	public static final String storageBinCode = "storageBinCode";
	/**
	 * 货物编号
	 */
	public static final String materialId = "materialId";
	/**
	 * 库存数量
	 */
	public static final String quantity = "quantity";
	
	public WmsInventoryBin(){
	}
	/**
	 * Get id
	 */
	public java.lang.Long getId() {
		return get(id);
	}
	
	/**
	 * Set id
	 */
	public WmsInventoryBin setId(java.lang.Long value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 仓库号
	 */
	public java.lang.String getStorageId() {
		return get(storageId);
	}
	
	/**
	 * Set 仓库号
	 */
	public WmsInventoryBin setStorageId(java.lang.String value) {
		set(storageId, value);
		return this;
	}
	/**
	 * Get 仓位Id
	 */
	public java.lang.Long getStorageBinId() {
		return get(storageBinId);
	}
	
	/**
	 * Set 仓位Id
	 */
	public WmsInventoryBin setStorageBinId(java.lang.Long value) {
		set(storageBinId, value);
		return this;
	}
	/**
	 * Get 仓位编号
	 */
	public java.lang.String getStorageBinCode() {
		return get(storageBinCode);
	}
	
	/**
	 * Set 仓位编号
	 */
	public WmsInventoryBin setStorageBinCode(java.lang.String value) {
		set(storageBinCode, value);
		return this;
	}
	/**
	 * Get 货物编号
	 */
	public java.lang.Long getMaterialId() {
		return get(materialId);
	}
	
	/**
	 * Set 货物编号
	 */
	public WmsInventoryBin setMaterialId(java.lang.Long value) {
		set(materialId, value);
		return this;
	}
	/**
	 * Get 库存数量
	 */
	public java.lang.Double getQuantity() {
		return get(quantity);
	}
	
	/**
	 * Set 库存数量
	 */
	public WmsInventoryBin setQuantity(java.lang.Double value) {
		set(quantity, value);
		return this;
	}
}

