/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * WmsStorageBin
 * @author 
 *
 */
public class WmsStorageBin extends Model<WmsStorageBin>{
	public static WmsStorageBin dao = new WmsStorageBin();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "wms_storage_bin";
	
	/**
	 * ID
	 */
	public static final String id = "id";
	/**
	 * 仓位号
	 */
	public static final String binCode = "binCode";
	/**
	 * 所属仓库
	 */
	public static final String storeId = "storeId";
	
	public WmsStorageBin(){
	}
	/**
	 * Get ID
	 */
	public java.lang.Long getId() {
		return get(id);
	}
	
	/**
	 * Set ID
	 */
	public WmsStorageBin setId(java.lang.Long value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 仓位号
	 */
	public java.lang.String getBinCode() {
		return get(binCode);
	}
	
	/**
	 * Set 仓位号
	 */
	public WmsStorageBin setBinCode(java.lang.String value) {
		set(binCode, value);
		return this;
	}
	/**
	 * Get 所属仓库
	 */
	public java.lang.String getStoreId() {
		return get(storeId);
	}
	
	/**
	 * Set 所属仓库
	 */
	public WmsStorageBin setStoreId(java.lang.String value) {
		set(storeId, value);
		return this;
	}
}

