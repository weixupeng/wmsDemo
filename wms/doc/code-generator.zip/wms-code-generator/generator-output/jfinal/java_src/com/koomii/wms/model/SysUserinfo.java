/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * SysUserinfo
 * @author 
 *
 */
public class SysUserinfo extends Model<SysUserinfo>{
	public static SysUserinfo dao = new SysUserinfo();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "sys_userinfo";
	
	/**
	 * 记录编号
	 */
	public static final String id = "id";
	/**
	 * 创建日期
	 */
	public static final String createDate = "createDate";
	/**
	 * 修改日期
	 */
	public static final String modifyDate = "modifyDate";
	/**
	 * 用户登录名
	 */
	public static final String username = "username";
	/**
	 * 真实姓名
	 */
	public static final String realname = "realname";
	/**
	 * 登录密码
	 */
	public static final String pwd = "pwd";
	/**
	 * 移动电话号码
	 */
	public static final String mobile = "mobile";
	/**
	 * 邮件
	 */
	public static final String email = "email";
	/**
	 * QQ
	 */
	public static final String qq = "qq";
	/**
	 * 电话
	 */
	public static final String tel = "tel";
	/**
	 * 备注
	 */
	public static final String memo = "memo";
	/**
	 * 是否停用
	 */
	public static final String inuse = "inuse";
	/**
	 * tag
	 */
	public static final String tag = "tag";
	/**
	 * 是否系统默认
	 */
	public static final String isSystem = "isSystem";
	
	public SysUserinfo(){
	}
	/**
	 * Get 记录编号
	 */
	public java.lang.String getId() {
		return get(id);
	}
	
	/**
	 * Set 记录编号
	 */
	public SysUserinfo setId(java.lang.String value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 创建日期
	 */
	public java.util.Date getCreateDate() {
		return get(createDate);
	}
	
	/**
	 * Set 创建日期
	 */
	public SysUserinfo setCreateDate(java.util.Date value) {
		set(createDate, value);
		return this;
	}
	/**
	 * Get 修改日期
	 */
	public java.util.Date getModifyDate() {
		return get(modifyDate);
	}
	
	/**
	 * Set 修改日期
	 */
	public SysUserinfo setModifyDate(java.util.Date value) {
		set(modifyDate, value);
		return this;
	}
	/**
	 * Get 用户登录名
	 */
	public java.lang.String getUsername() {
		return get(username);
	}
	
	/**
	 * Set 用户登录名
	 */
	public SysUserinfo setUsername(java.lang.String value) {
		set(username, value);
		return this;
	}
	/**
	 * Get 真实姓名
	 */
	public java.lang.String getRealname() {
		return get(realname);
	}
	
	/**
	 * Set 真实姓名
	 */
	public SysUserinfo setRealname(java.lang.String value) {
		set(realname, value);
		return this;
	}
	/**
	 * Get 登录密码
	 */
	public java.lang.String getPwd() {
		return get(pwd);
	}
	
	/**
	 * Set 登录密码
	 */
	public SysUserinfo setPwd(java.lang.String value) {
		set(pwd, value);
		return this;
	}
	/**
	 * Get 移动电话号码
	 */
	public java.lang.String getMobile() {
		return get(mobile);
	}
	
	/**
	 * Set 移动电话号码
	 */
	public SysUserinfo setMobile(java.lang.String value) {
		set(mobile, value);
		return this;
	}
	/**
	 * Get 邮件
	 */
	public java.lang.String getEmail() {
		return get(email);
	}
	
	/**
	 * Set 邮件
	 */
	public SysUserinfo setEmail(java.lang.String value) {
		set(email, value);
		return this;
	}
	/**
	 * Get QQ
	 */
	public java.lang.String getQq() {
		return get(qq);
	}
	
	/**
	 * Set QQ
	 */
	public SysUserinfo setQq(java.lang.String value) {
		set(qq, value);
		return this;
	}
	/**
	 * Get 电话
	 */
	public java.lang.String getTel() {
		return get(tel);
	}
	
	/**
	 * Set 电话
	 */
	public SysUserinfo setTel(java.lang.String value) {
		set(tel, value);
		return this;
	}
	/**
	 * Get 备注
	 */
	public java.lang.String getMemo() {
		return get(memo);
	}
	
	/**
	 * Set 备注
	 */
	public SysUserinfo setMemo(java.lang.String value) {
		set(memo, value);
		return this;
	}
	/**
	 * Get 是否停用
	 */
	public java.lang.Integer getInuse() {
		return get(inuse);
	}
	
	/**
	 * Set 是否停用
	 */
	public SysUserinfo setInuse(java.lang.Integer value) {
		set(inuse, value);
		return this;
	}
	/**
	 * Get tag
	 */
	public java.lang.String getTag() {
		return get(tag);
	}
	
	/**
	 * Set tag
	 */
	public SysUserinfo setTag(java.lang.String value) {
		set(tag, value);
		return this;
	}
	/**
	 * Get 是否系统默认
	 */
	public java.lang.Boolean getIsSystem() {
		return get(isSystem);
	}
	
	/**
	 * Set 是否系统默认
	 */
	public SysUserinfo setIsSystem(java.lang.Boolean value) {
		set(isSystem, value);
		return this;
	}
}

