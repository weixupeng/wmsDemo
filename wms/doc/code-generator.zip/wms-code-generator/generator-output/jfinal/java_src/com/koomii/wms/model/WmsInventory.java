/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * WmsInventory
 * @author 
 *
 */
public class WmsInventory extends Model<WmsInventory>{
	public static WmsInventory dao = new WmsInventory();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "wms_inventory";
	
	/**
	 * id
	 */
	public static final String id = "id";
	/**
	 * 仓库
	 */
	public static final String storageId = "storageId";
	/**
	 * 货号
	 */
	public static final String materialId = "materialId";
	/**
	 * 库存数量
	 */
	public static final String quantity = "quantity";
	
	public WmsInventory(){
	}
	/**
	 * Get id
	 */
	public java.lang.Long getId() {
		return get(id);
	}
	
	/**
	 * Set id
	 */
	public WmsInventory setId(java.lang.Long value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 仓库
	 */
	public java.lang.String getStorageId() {
		return get(storageId);
	}
	
	/**
	 * Set 仓库
	 */
	public WmsInventory setStorageId(java.lang.String value) {
		set(storageId, value);
		return this;
	}
	/**
	 * Get 货号
	 */
	public java.lang.Long getMaterialId() {
		return get(materialId);
	}
	
	/**
	 * Set 货号
	 */
	public WmsInventory setMaterialId(java.lang.Long value) {
		set(materialId, value);
		return this;
	}
	/**
	 * Get 库存数量
	 */
	public java.lang.Double getQuantity() {
		return get(quantity);
	}
	
	/**
	 * Set 库存数量
	 */
	public WmsInventory setQuantity(java.lang.Double value) {
		set(quantity, value);
		return this;
	}
}

