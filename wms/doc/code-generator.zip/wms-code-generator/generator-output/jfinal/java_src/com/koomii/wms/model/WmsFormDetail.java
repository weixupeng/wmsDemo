/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * WmsFormDetail
 * @author 
 *
 */
public class WmsFormDetail extends Model<WmsFormDetail>{
	public static WmsFormDetail dao = new WmsFormDetail();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "wms_form_detail";
	
	/**
	 * 编号
	 */
	public static final String id = "id";
	/**
	 * 所属单据
	 */
	public static final String formId = "formId";
	/**
	 * 货物编号
	 */
	public static final String materialId = "materialId";
	/**
	 * 货物名称
	 */
	public static final String materialName = "materialName";
	/**
	 * 数量
	 */
	public static final String quantity = "quantity";
	/**
	 * 仓位Id
	 */
	public static final String storageBinId = "storageBinId";
	/**
	 * 仓位编号
	 */
	public static final String storageBinCode = "storageBinCode";
	
	public WmsFormDetail(){
	}
	/**
	 * Get 编号
	 */
	public java.lang.Long getId() {
		return get(id);
	}
	
	/**
	 * Set 编号
	 */
	public WmsFormDetail setId(java.lang.Long value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 所属单据
	 */
	public java.lang.Long getFormId() {
		return get(formId);
	}
	
	/**
	 * Set 所属单据
	 */
	public WmsFormDetail setFormId(java.lang.Long value) {
		set(formId, value);
		return this;
	}
	/**
	 * Get 货物编号
	 */
	public java.lang.Long getMaterialId() {
		return get(materialId);
	}
	
	/**
	 * Set 货物编号
	 */
	public WmsFormDetail setMaterialId(java.lang.Long value) {
		set(materialId, value);
		return this;
	}
	/**
	 * Get 货物名称
	 */
	public java.lang.String getMaterialName() {
		return get(materialName);
	}
	
	/**
	 * Set 货物名称
	 */
	public WmsFormDetail setMaterialName(java.lang.String value) {
		set(materialName, value);
		return this;
	}
	/**
	 * Get 数量
	 */
	public java.lang.Double getQuantity() {
		return get(quantity);
	}
	
	/**
	 * Set 数量
	 */
	public WmsFormDetail setQuantity(java.lang.Double value) {
		set(quantity, value);
		return this;
	}
	/**
	 * Get 仓位Id
	 */
	public java.lang.Long getStorageBinId() {
		return get(storageBinId);
	}
	
	/**
	 * Set 仓位Id
	 */
	public WmsFormDetail setStorageBinId(java.lang.Long value) {
		set(storageBinId, value);
		return this;
	}
	/**
	 * Get 仓位编号
	 */
	public java.lang.String getStorageBinCode() {
		return get(storageBinCode);
	}
	
	/**
	 * Set 仓位编号
	 */
	public WmsFormDetail setStorageBinCode(java.lang.String value) {
		set(storageBinCode, value);
		return this;
	}
}

