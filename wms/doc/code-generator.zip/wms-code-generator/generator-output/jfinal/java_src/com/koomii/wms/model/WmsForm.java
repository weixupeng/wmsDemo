/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * WmsForm
 * @author 
 *
 */
public class WmsForm extends Model<WmsForm>{
	public static WmsForm dao = new WmsForm();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "wms_form";
	
	/**
	 * 单据号
	 */
	public static final String id = "id";
	/**
	 * 单据类型（0入库、1出库、2移库、3盘点）
	 */
	public static final String type = "type";
	/**
	 * 创建时间
	 */
	public static final String createDate = "createDate";
	/**
	 * 作业人
	 */
	public static final String worker = "worker";
	/**
	 * 业务发生时间
	 */
	public static final String optime = "optime";
	/**
	 * 入库仓库
	 */
	public static final String inStorage = "inStorage";
	/**
	 * 出库仓库
	 */
	public static final String outStorage = "outStorage";
	/**
	 * 盘点仓库
	 */
	public static final String stStorage = "stStorage";
	/**
	 * 供应商/客户
	 */
	public static final String customer = "customer";
	/**
	 * 状态（0草稿1已过账）
	 */
	public static final String status = "status";
	/**
	 * 操作人
	 */
	public static final String operator = "operator";
	
	public WmsForm(){
	}
	/**
	 * Get 单据号
	 */
	public java.lang.Long getId() {
		return get(id);
	}
	
	/**
	 * Set 单据号
	 */
	public WmsForm setId(java.lang.Long value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 单据类型（0入库、1出库、2移库、3盘点）
	 */
	public java.lang.Integer getType() {
		return get(type);
	}
	
	/**
	 * Set 单据类型（0入库、1出库、2移库、3盘点）
	 */
	public WmsForm setType(java.lang.Integer value) {
		set(type, value);
		return this;
	}
	/**
	 * Get 创建时间
	 */
	public java.util.Date getCreateDate() {
		return get(createDate);
	}
	
	/**
	 * Set 创建时间
	 */
	public WmsForm setCreateDate(java.util.Date value) {
		set(createDate, value);
		return this;
	}
	/**
	 * Get 作业人
	 */
	public java.lang.Long getWorker() {
		return get(worker);
	}
	
	/**
	 * Set 作业人
	 */
	public WmsForm setWorker(java.lang.Long value) {
		set(worker, value);
		return this;
	}
	/**
	 * Get 业务发生时间
	 */
	public java.util.Date getOptime() {
		return get(optime);
	}
	
	/**
	 * Set 业务发生时间
	 */
	public WmsForm setOptime(java.util.Date value) {
		set(optime, value);
		return this;
	}
	/**
	 * Get 入库仓库
	 */
	public java.lang.String getInStorage() {
		return get(inStorage);
	}
	
	/**
	 * Set 入库仓库
	 */
	public WmsForm setInStorage(java.lang.String value) {
		set(inStorage, value);
		return this;
	}
	/**
	 * Get 出库仓库
	 */
	public java.lang.String getOutStorage() {
		return get(outStorage);
	}
	
	/**
	 * Set 出库仓库
	 */
	public WmsForm setOutStorage(java.lang.String value) {
		set(outStorage, value);
		return this;
	}
	/**
	 * Get 盘点仓库
	 */
	public java.lang.String getStStorage() {
		return get(stStorage);
	}
	
	/**
	 * Set 盘点仓库
	 */
	public WmsForm setStStorage(java.lang.String value) {
		set(stStorage, value);
		return this;
	}
	/**
	 * Get 供应商/客户
	 */
	public java.lang.String getCustomer() {
		return get(customer);
	}
	
	/**
	 * Set 供应商/客户
	 */
	public WmsForm setCustomer(java.lang.String value) {
		set(customer, value);
		return this;
	}
	/**
	 * Get 状态（0草稿1已过账）
	 */
	public java.lang.Integer getStatus() {
		return get(status);
	}
	
	/**
	 * Set 状态（0草稿1已过账）
	 */
	public WmsForm setStatus(java.lang.Integer value) {
		set(status, value);
		return this;
	}
	/**
	 * Get 操作人
	 */
	public java.lang.String getOperator() {
		return get(operator);
	}
	
	/**
	 * Set 操作人
	 */
	public WmsForm setOperator(java.lang.String value) {
		set(operator, value);
		return this;
	}
}

