/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.controller;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.aop.Before;
import com.jfinal.plugin.activerecord.tx.Tx;
import com.koomii.base.BaseController;

/**
 * WmsMaterial
 * @author 
 *
 */
public class WmsMaterialController extends BaseController{
	
	public void index(){
			renderText(""HelloIndex");
	}

}