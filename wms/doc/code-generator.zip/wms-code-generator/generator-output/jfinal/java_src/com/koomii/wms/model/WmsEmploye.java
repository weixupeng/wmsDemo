/*
 * Powered By JFinal & DWZ & MySQL & Eclipse
 * CopyRight @- 2013
 */

package com.koomii.wms.model;

import java.util.*;
import util.*;
import com.koomii.wms.model.*;
import com.jfinal.plugin.activerecord.Model;


/**
 * WmsEmploye
 * @author 
 *
 */
public class WmsEmploye extends Model<WmsEmploye>{
	public static WmsEmploye dao = new WmsEmploye();
	/**
	 * The mapper table of this class
	 */
	public static final String tableName = "wms_employe";
	
	/**
	 * 编码
	 */
	public static final String id = "id";
	/**
	 * 名称
	 */
	public static final String name = "name";
	
	public WmsEmploye(){
	}
	/**
	 * Get 编码
	 */
	public java.lang.Long getId() {
		return get(id);
	}
	
	/**
	 * Set 编码
	 */
	public WmsEmploye setId(java.lang.Long value) {
		set(id, value);
		return this;
	}
	/**
	 * Get 名称
	 */
	public java.lang.String getName() {
		return get(name);
	}
	
	/**
	 * Set 名称
	 */
	public WmsEmploye setName(java.lang.String value) {
		set(name, value);
		return this;
	}
}

